<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Solicitud_categoria extends Model
{
    protected $table = 'solicitud_categoria';
    protected $primaryKey = 'id';
    public $timestamps = false;

}