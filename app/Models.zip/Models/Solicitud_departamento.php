<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Solicitud_departamento extends Model
{
    protected $table = 'solicitud_departamento';
    protected $primaryKey = 'id';
    public $timestamps = false;

}