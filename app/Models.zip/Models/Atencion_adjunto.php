<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Atencion_adjunto extends Model
{
    protected $table = 'atencion_adjunto';
    protected $primaryKey = 'id';
    public $timestamps = false;

} 