<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Categoria_departamento extends Model
{
    protected $table = 'categoria_departamento';
    protected $primaryKey = 'id';
    public $timestamps = false;
} 