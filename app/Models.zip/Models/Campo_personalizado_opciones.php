<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Campo_personalizado_opciones extends Model
{
    protected $table = 'campo_personalizado_opciones';
    protected $primaryKey = 'id_campo_personalizado_opciones';
    public $timestamps = false;

} 