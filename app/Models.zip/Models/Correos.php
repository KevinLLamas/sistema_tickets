<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Correos extends Model
{
    protected $table = 'correos';
    protected $primaryKey = 'id';
    public $timestamps = false;
} 