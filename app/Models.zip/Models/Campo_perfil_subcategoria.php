<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Campo_perfil_subcategoria extends Model
{
    protected $table = 'campo_perfil_subcategoria';
    protected $primaryKey = 'id';
    public $timestamps = false;

} 