<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Solicitud_dato_adicional extends Model
{
    protected $table = 'solicitud_dato_adicional';
    protected $primaryKey = 'id';
    public $timestamps = false;

}