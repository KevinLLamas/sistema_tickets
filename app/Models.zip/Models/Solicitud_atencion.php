<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Solicitud_atencion extends Model
{
    protected $table = 'solicitud_atencion';
    protected $primaryKey = 'id';
    public $timestamps = false;

}