<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Grupo_trabajador extends Model
{
    protected $table = 'grupo_trabajador';
    protected $primaryKey = 'id_usuario';
    public $timestamps = false;
} 