<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Solicitud_usuario extends Model
{
    protected $table = 'solicitud_usuario';
    protected $primaryKey = 'id';
    public $timestamps = false;

}