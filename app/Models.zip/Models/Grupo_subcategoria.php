<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Grupo_subcategoria extends Model
{
    protected $table = 'grupo_subcategoria';
    protected $primaryKey = 'id_subcategoria';
    public $timestamps = false;
} 