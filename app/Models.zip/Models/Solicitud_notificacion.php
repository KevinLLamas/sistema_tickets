<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Solicitud_notificacion extends Model
{
    protected $table = 'solicitud_notificacion';
    protected $primaryKey = 'id';
    public $timestamps = false;

}