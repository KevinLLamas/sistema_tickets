<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Notificacion_usuario extends Model
{
    protected $table = 'notificacion_usuario';
    protected $primaryKey = 'id';
    public $timestamps = false;

}